const filterBranch = ["computer science", "Electronic & Communication","Mechanical / Arichiceture",
"civil / archicture" ]
const dummyData = [
    {
        "Branch": "computer science",
         "CourseTitle":"Machine Learning with Python",
         "duration" : "2 year",
         "knowMore":"know more",
         "image": "/images/image 7.png"
    },
    {
        "Branch": "computer science",
         "CourseTitle":"Machine Learning with Python",
         "duration" : "2 year",
         "knowMore":"know more",
         "image": "/images/image 7.png"
    },
    {
        "Branch": "computer science",
         "CourseTitle":"Machine Learning with Python",
         "duration" : "2 year",
         "knowMore":"know more",
         "image": "/images/image 7.png"
    },
    {
        "Branch": "computer science",
         "CourseTitle":"Machine Learning with Python",
         "duration" : "2 year",
         "knowMore":"know more",
         "image": "/images/image 7.png"
    },
    {
        "Branch": "computer science",
         "CourseTitle":"Machine Learning with Python",
         "duration" : "2 year",
         "knowMore":"know more",
         "image": "/images/image 7.png"
    },
    {
        "Branch": "Electronic & Communication",
         "CourseTitle":"Machine Learning with R",
         "duration" : "2 year",
         "knowMore":"know more",
         "image": "/images/image 7.png"
    }
    ,
    {
        "Branch": "Electronic & Communication",
         "CourseTitle":"Machine Learning with R",
         "duration" : "2 year",
         "knowMore":"know more",
         "image": "/images/image 7.png"
    }
    ,
    {
        "Branch": "Electronic & Communication",
         "CourseTitle":"Machine Learning with R",
         "duration" : "2 year",
         "knowMore":"know more",
         "image": "/images/image 7.png"
    }
    ,
    {
        "Branch": "Electronic & Communication",
         "CourseTitle":"Machine Learning with R",
         "duration" : "2 year",
         "knowMore":"know more",
         "image": "/images/image 7.png"
    }
    ,
    {
        "Branch": "Electronic & Communication",
         "CourseTitle":"Machine Learning with R",
         "duration" : "2 year",
         "knowMore":"know more",
         "image": "/images/image 7.png"
    }

]
export {filterBranch,dummyData}