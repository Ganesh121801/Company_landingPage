import React from 'react'

function SigninEmail() {
  return (
    <div>SigninEmail</div>
  )
}

export default SigninEmail